import React from 'react'
import achievements from '../data/achievements'
import useKeyChallenges from '../hooks/useKeyChallenges'

export default function UnlockedPage() {
  const { unlocked, progress, resetAll } = useKeyChallenges()
  const list = achievements.filter(a => unlocked[a.id])

  return (
    <div style={{padding:16}}>
      <h1>Unlocked Achievements</h1>
      <p>Progress: {progress}%</p>
      <button className="pill" onClick={resetAll}>Reset</button>
      <div className="grid" style={{marginTop:12}}>
        {list.map(a => (
          <div key={a.id} className="card">
            <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
              <strong>{a.title}</strong>
              <span className="badge" style={{color:'var(--ok)'}}>Unlocked</span>
            </div>
            <p style={{marginTop:8, opacity:.9}}>{a.description}</p>
            {a.highlights?.length ? (
              <ul style={{margin: '8px 0 0 16px'}}>
                {a.highlights.map((h, i) => (<li key={i}>{h}</li>))}
              </ul>
            ) : null}
          </div>
        ))}
      </div>
    </div>
  )
}
