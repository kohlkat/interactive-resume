import React from 'react'
import QrCard from '../components/QrCard'

export default function ContactPage() {
  const url = typeof window !== 'undefined' ? window.location.origin + (import.meta.env.BASE_URL ?? '/') : ''
  return (
    <div style={{padding:16, display:'grid', gap:12}}>
      <h1>Contact</h1>
      <p>Grab my vCard and a QR that points to this interactive resume.</p>
      <QrCard url={url} />
    </div>
  )
}
